from flask import Flask, render_template, request, url_for

app = Flask(__name__)


@app.route("/")
def home():
    return render_template("home.html", active_page="home")


@app.route("/about")
def about():
    return render_template("about.html", active_page="about")


@app.route("/gallery")
def gallery():
    images = [
        {"src": url_for("static", filename="images/stock1.jpg"), "alt": "Stock image one"},
        {"src": url_for("static", filename="images/stock2.jpg"), "alt": "Stock image two"},
        {"src": url_for("static", filename="images/stock3.jpg"), "alt": "Stock image three"},
    ]
    return render_template("gallery.html", active_page="gallery", images=images)


@app.route("/article")
def article():
    return render_template("article.html", active_page="article")


@app.route("/contact", methods=["GET", "POST"])
def contact():
    sent = False
    if request.method == "POST": # when sent is true, the thank you message will appear
        sent = True
    return render_template("contact.html", active_page="contact", sent=sent) # this returns true or false for sent


if __name__ == "__main__":
    app.run(debug=True)
